-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2021 at 06:43 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` varchar(5) NOT NULL,
  `cat_img` varchar(200) DEFAULT NULL,
  `cat_ban` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `name`, `status`, `cat_img`, `cat_ban`) VALUES
(1, 'grocery', '1', 'grocery.jpg', 'grocery_Cat-Banar.jpg'),
(2, 'beauty', '1', 'beauty.jpg', 'beauty_Cat-Banar.jpg'),
(3, 'personal care', '1', 'person.jpg', 'personal care_Cat-Banar.jpg'),
(4, 'home', '1', 'home.jpg', 'home_Cat-Banar.jpg'),
(5, 'pharmacy', '1', 'medi.jpg', 'pharmacy_Cat-Banar.jpg'),
(6, 'baby care', '1', 'baby.jpg', 'blanket & comforter.jpg'),
(7, 'more', '1', 'more.jpg', 'beauty_Cat-Banar.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(30) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `city` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `phone` int(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `billing_address` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `first_name`, `last_name`, `Address`, `city`, `country`, `phone`, `email`, `password`, `billing_address`) VALUES
(1, 'yeasin', 'Tanin', 'wirelessgate', 'Dhaka', 'Bangladesh', 1992435678, 'yeasintanin@gmail.com', '123456789', 'wirelessgate, dhaka'),
(2, 'shahariar', 'rahman', 'wirelessgate', 'Dhaka', 'Bangladesh', 1992435678, 'shahariar@gmail.com', '12345678', 'wirelessgate, dhaka'),
(3, 'Salma', 'Akter', 'wirelessgate3', 'dhaka', 'bangladesh', 1982345678, 'salma@gmail.com', '1234567', 'wirelessgate3, dhaka'),
(4, 'masud  ', 'rana', 'ert', 'wtew', 'Bangladesh', 1754345543, 'masudrana100855@gmail.com', '11111111', 'wtgwe'),
(5, 'masud', 'rana', 'ertrrrrrrrrrr', 'wtewrrrrrrrr', 'Bangladesh', 1754345543, 'masudrana100855@gmail.com', '', 'rrrrrrrrrrrrrrrr'),
(6, 'masud fffffff', 'ranafffffffffffffff', 'ert', '', 'Bangladesh', 1754345543, 'masudrana100855@gmail.com', '', 'wtgwe');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `address` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `total` int(11) NOT NULL,
  `pay_method` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(30) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `address`, `phone`, `total`, `pay_method`, `created_at`, `updated_at`, `status`) VALUES
(3, 1, 'flat 13-b, gulshan terrace, Mu', '03332975389', 15002, 'paypal', '2020-11-14 22:50:18', '2020-11-14 22:50:18', 'completed'),
(4, 1, 'Sanarota', '03332975389', 15002, 'bkash', '2020-11-14 22:57:55', '2020-11-14 22:57:55', 'pending'),
(22, 3, 'bibuuu', '1234', 1175, 'cash on delivery', '2021-02-08 06:59:05', '2021-02-08 06:59:05', 'pending'),
(23, 3, 'wirelessgate3, dhaka', '1982345678', 640, 'cash on delivery', '2021-02-08 07:24:09', '2021-02-08 07:24:09', 'pending'),
(24, 4, 'mohakhali,dhaka', '23113321', 490, 'cash on delivery', '2021-02-09 07:17:44', '2021-02-09 07:17:44', 'pending'),
(25, 4, 'mohakhali,dhaka', '23113321', 490, 'cash', '2021-02-10 09:47:43', '2021-02-10 09:47:43', 'pending'),
(26, 4, 'ert', '1754345543', 0, 'cash', '2021-02-11 06:03:54', '2021-02-11 06:03:54', 'pending'),
(27, 4, 'ert', '1754345543', 0, 'cash', '2021-02-11 06:06:06', '2021-02-11 06:06:06', 'pending'),
(28, 4, 'ert', '1754345543', 0, 'paypal', '2021-02-11 06:09:08', '2021-02-11 06:09:08', 'pending'),
(29, 4, 'ert', '1754345543', 0, 'cash', '2021-02-11 06:59:46', '2021-02-11 06:59:46', 'pending'),
(30, 4, 'ert', '1754345543', 5000, 'cash', '2021-02-11 07:04:31', '2021-02-11 07:04:31', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `quantity`, `created_at`, `updated_at`) VALUES
(1, 5, 9, 1, '2020-11-14 23:03:39', '2020-11-14 23:03:39'),
(2, 6, 9, 1, '2020-11-14 23:11:07', '2020-11-14 23:11:07'),
(3, 8, 9, 1, '2020-11-19 07:10:05', '2020-11-19 07:10:05'),
(4, 9, 9, 1, '2020-11-19 07:10:14', '2020-11-19 07:10:14'),
(5, 10, 9, 1, '2020-11-19 07:12:15', '2020-11-19 07:12:15'),
(6, 11, 9, 1, '2020-11-19 07:12:51', '2020-11-19 07:12:51'),
(7, 12, 9, 1, '2020-11-19 07:13:15', '2020-11-19 07:13:15'),
(8, 13, 9, 1, '2020-11-19 07:17:39', '2020-11-19 07:17:39'),
(9, 14, 9, 1, '2020-11-19 07:17:51', '2020-11-19 07:17:51'),
(10, 15, 9, 1, '2020-11-19 07:19:04', '2020-11-19 07:19:04'),
(11, 16, 9, 1, '2020-11-19 07:19:10', '2020-11-19 07:19:10'),
(12, 17, 9, 1, '2020-11-19 07:19:25', '2020-11-19 07:19:25'),
(13, 18, 9, 1, '2020-11-19 07:19:36', '2020-11-19 07:19:36'),
(14, 19, 9, 1, '2020-11-19 07:21:22', '2020-11-19 07:21:22'),
(15, 20, 9, 1, '2020-11-19 07:21:32', '2020-11-19 07:21:32'),
(16, 4, 13, 1, '2020-11-19 08:12:43', '2020-11-19 08:12:43'),
(17, 4, 13, 1, '2020-11-19 08:12:50', '2020-11-19 08:12:50'),
(18, 4, 13, 1, '2020-11-19 08:13:09', '2020-11-19 08:13:09'),
(19, 4, 13, 1, '2020-11-19 08:13:38', '2020-11-19 08:13:38'),
(20, 21, 13, 1, '2020-11-19 08:15:32', '2020-11-19 08:15:32'),
(21, 22, 2, 1, '2021-02-08 06:59:05', '2021-02-08 06:59:05'),
(22, 22, 16, 1, '2021-02-08 06:59:06', '2021-02-08 06:59:06'),
(23, 22, 1, 1, '2021-02-08 06:59:06', '2021-02-08 06:59:06'),
(24, 22, 5, 1, '2021-02-08 06:59:06', '2021-02-08 06:59:06'),
(25, 0, 1, 1, '2021-02-11 06:03:54', '2021-02-11 06:03:54'),
(26, 0, 31, 1, '2021-02-11 06:06:06', '2021-02-11 06:06:06'),
(27, 0, 32, 1, '2021-02-11 06:06:06', '2021-02-11 06:06:06'),
(28, 0, 33, 1, '2021-02-11 06:06:06', '2021-02-11 06:06:06'),
(29, 0, 39, 1, '2021-02-11 06:09:08', '2021-02-11 06:09:08'),
(30, 0, 1, 1, '2021-02-11 06:59:46', '2021-02-11 06:59:46'),
(31, 30, 31, 1, '2021-02-11 07:04:31', '2021-02-11 07:04:31'),
(32, 30, 32, 2, '2021-02-11 07:04:31', '2021-02-11 07:04:31');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(30) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `type`) VALUES
(1, 'cash on delivery'),
(2, 'bkash');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(30) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `product_limit` int(30) NOT NULL,
  `sub_cat_id` int(30) NOT NULL,
  `type_id` int(30) NOT NULL,
  `unit_id` int(30) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `product_details` varchar(5000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `p_name`, `price`, `product_limit`, `sub_cat_id`, `type_id`, `unit_id`, `image`, `product_details`) VALUES
(1, 'Teer_Soyaben_oil', 490, 10, 1, 2, 1, 'teer_Soyaben_oil.jpg', 'Teer soyaben oil is true “The world healthiest” edible oil.\r\nIt contains Vitamins, antioxidants, nutrients, and trans-fat-free.\r\nIt is naturally cholesterol and trans-fat-free.\r\nIt helps to maintain the nervous system.'),
(2, 'Rupchanda_Soybean_oil', 150, 5, 1, 2, 1, 'Rupchanda_Soybean_oil.jpg', 'Rupchanda soybean oil is true “The world healthiest” edible oil. It contains Vitamins, antioxidants, nutrients, and trans-fat-free. It is naturally cholesterol and trans-fat-free. It helps to maintain the nervous system.'),
(3, 'minicat_rice_1', 60, 50, 1, 1, 8, 'umbrella.jpg', 'Minicat Rice'),
(4, 'ACI-Flour', 200, 50, 1, 35, 8, 'ACI Vacuum Salt.jpg', 'ACI Pure Flour is using World famous European Technology “Ocrim Machine” for its production which is completely automated.ACI Pure takes extra care to keep things as natural as possible.It plays a vital role in strengthening immunity and extra protein to improve body strength.'),
(5, 'ACI Vacuum Salt', 35, 10, 1, 5, 8, 'ACI Vacuum Salt.jpg', 'Iodine helps in the mental development of chilDren and prevents iodine deficiency disorders in adultsSea salt recommended by doctors and health professionals for its unique blend of trace minerals.Convenient for cooking,baking,and finishing.No artificial flavors,colors.'),
(6, 'H&S AD COOL MENTHOL SHAMPOO', 110, 50, 11, 51, 26, 'shampoo.jpg', '\r\nH&S AD COOL MENTHOL SHAMPOO 1000ML'),
(7, '\r\nSANDALINA WOOD SOAP', 110, 50, 13, 47, 26, 'SANDALINA WOOD SOAP.jpg', 'SANDALINA WOOD SOAP 125g is made from natural sandalwood oil and moisturizing complex.It soften, smoothen and perfume your skin.It is made for specially take care of most delicate skin.'),
(8, 'Savlon Men Soap', 50, 50, 13, 47, 0, 'Savlon Men Soap.jpg', 'Savlon Men Soao is a refreshing product for bath.It contains certain chemicals not found in plain soaps.It is more effective than regular soap and water for killing disease-causing germs'),
(9, 'Nido 1 plus', 23, 10, 33, 14, 26, 'Nido 1 plus 1800g.jpg', 'NIDO 1+ starts with the goodness of milk.It alos includes vitamins, minerals, and prebiotics.It increses growth, development.Also builds a healthy immune system'),
(10, 'Meril Baby Lotion', 56, 50, 32, 15, 12, 'lotion.jpg', 'When you are taking care of your child, the sweet fragrance and gentleness of Meril Baby Lotion will make the experience even more pleasant for both of you.While you will be giving your loving protection, your child would play with you, dabbing some lotion on your nose or cheek in return.As with other products in this line, Meril Baby Lotion is specially designed to meet the needs of Bangladeshi children, keeping our climate and environment in mind.'),
(11, 'HUGGIES DRY DIAPERS', 144, 50, 30, 16, 26, 'HUGGIES DRY DIAPERS.jpg', 'Huggies® Diaper technology for dryness and breathability is clinically proven++ to help prevent diaper rash or dermatitis.Provides overnight protection^ with a super-absorbent gel which helps to absorb and lock fluid inside.Absorbs fluid quickly to help keep your baby’s skin dry.Allows air to escape 10x faster+ through outer cover so the baby’s skin '),
(12, 'Romania Lexus Vegetable Crackers', 200, 50, 4, 17, 5, 'ACI Vacuum Salt.jpg', 'Romania Lexus Vegetable Crackers (240g) is available in buy 2 get 1 offer.It is a delicious crunchy biscuit.It has high amount of nutrition value.Its a vegetable flavour biscuit.'),
(13, 'Fresh Toilet Tissue Pink', 16, 50, 13, 18, 26, 'Fresh Toilet Tissue Pink.jpg', 'Fresh Toilet Tissue Pink is a good quality product.This is 100% hygienic.Its water absorbent quality is super.It feels super soft. It is a pink colour toilet tissue.'),
(14, 'Coopers Brown Bread', 432, 50, 4, 17, 26, 'bread.jpg', 'Brown Breads are high in fibre and other nutrients as compared to white bread since the flour is not processed much.The fibre present in brown bread can help reduce the risk of some chronic diseases like constipation etc.It also helps keep the blood sugar at lower levels, thus helping one to manage diabetes better.'),
(15, 'Fair & Lovely Adv Mv Hd Glow Cream', 456, 50, 10, 18, 14, 'Fair & Lovely Adv Mv Hd Glow Cream.jpg', 'Fair & Lovely Advanced Multivitamin is a face cream with the hero ingredient of multivitamins, which are understood to work from within to give skin a blemish-free glow along with a smooth and soft texture.Women today want more skin quality led benefits like a radiant glow, skin that is free from blemishes and imperfections.While this new aspiration of skin, has visible radiance, it is also strongly associated with the quality of skin itself.'),
(16, 'Vaseline I Care A Soothe B Lotion', 22345, 50, 10, 18, 12, 'grocery.jpg', 'Vaseline I Care Aloe Vera Soothe Body Lotion combines healing micro-droplets of Vaseline Jelly with Aloe Vera.Its ingredient Aloe Vera Soothes the skin.It has been clinically proven to moisturize deeply to soothe dry skin with the first application.'),
(17, 'Pepsodent Herbal Action Tooth Past', 260, 50, 15, 18, 26, 'Pepsodent Herbal Action Tooth Past.jpg', 'Pepsodent Herbal Action Toothpaste made from natural ingredients.It prevents cavities and gives fresh breath.It is a formulation of herbal and lime.'),
(18, 'TRISA COOL & FRESH MEDIUM TOOTH BRUSH', 255, 50, 15, 18, 26, 'TRISA COOL & FRESH MEDIUM TOOTH BRUSH.jpg', 'TRISA COOL & FRESH MEDIUM TOOTH BRUSH\'s whitening Filaments help to remove discolouration.It has ergonomical soft wave structure.It developed and produced in Switzerland.It has dual height cut.Colours of filaments harmonized with the colours of the handle.Trisa bristles are of special filament named Tynex which combines nylon(612) in a special formulation to deliver strength, stiffness, durability moisture resistance (even in a wet condition).'),
(19, 'Sharbat Rooh Afza', 150, 15, 9, 10, 1, 'Sharbat Rooh Afza.jpg', 'Sharbat Rooh Afza (750ml) is a fruit-filled, friendly drink.It is a perfect treat on a hot day.It has been the countrys favorite drink for generations.'),
(20, 'Aarong Dairy Laban', 30, 50, 9, 10, 12, 'Aarong Dairy Laban.jpg', 'Aarong Dairy Laban is a Aarong Dairy’s milk-based beverage.It is very tasty.It has high nutrition value.It adds a whole lot of goodness to every occasion.'),
(21, 'Boost Bib', 290, 5, 9, 10, 5, 'Aarong Sour Curd.jpg', ''),
(22, 'Horlicks Bottle', 500, 10, 9, 10, 26, 'Horlicks Bottle.jpg', 'Health Drink that has nutrients to support immunity.Clinically proven to improve 5 signs of growthClinically proven to make kids Taller, Stronger & SharperScientifically proven to improve Power of Milk'),
(23, 'Special Bashmoti rice', 67, 50, 1, 1, 8, 'bashmoti.jpg', 'Special Bashmoti rice'),
(24, 'Chinigura rice', 120, 50, 1, 1, 8, 'bashmoti.jpg', '\r\nChinigura rice'),
(25, 'Moshur daal', 80, 30, 1, 4, 8, 'masoor-dal.jpg', 'Moshur daal'),
(26, 'Mashkolai daal', 678, 25, 1, 4, 8, 'mashkolai_daal.jpg', 'Mashkolai daal'),
(27, 'Mug daal', 67, 30, 1, 4, 8, 'mug_daal.jpg', 'Mug daal'),
(28, 'But daal', 78, 25, 1, 4, 8, 'but_daal.jpg', 'But daal'),
(29, 'Elach', 89, 30, 1, 3, 5, 'elach.jpg', 'Elach'),
(30, 'Daruchini', 890, 50, 1, 3, 5, 'daruchini.jpg', 'Cinnamon contains large amounts of highly potent polyphenol antioxidants.The antioxidants in cinnamon have anti-inflammatory effects, which may help lower your risk of disease.Cinnamon may improve some key risk factors for heart disease, including cholesterol, triglycerides, and blood pressure.Cinnamon has been shown to significantly increase sensitivity to the hormone insulin.Animal and test-tube studies indicate that cinnamon may have protective effects against cancer.'),
(31, 'Beef', 90, 30, 2, 6, 8, 'beef.jpg', 'Beef Provides a Large Source of L-CarnitineBones themselves are rich in vitamins and nutrients, including calcium, magnesium, and phosphorus.Beef Provides the “Master Antioxidant” Glutathione.Beef is High in Protein and Helps Improve Muscle MassBeef is Extremely Rich in MineralsEating Beef Helps Prevent Iron Deficiency AnemiaBeef Contains Carnosine, a Potent Amino Acid.'),
(32, 'Mutton', 900, 100, 2, 6, 8, 'mutton.jpg', 'Reduces the risk of atherosclerosis and coronary heart disease.Good source of conjugated linoleic acid (CLA)- a fatty acid that may help prevent cancer and other inflammatory conditions.It contains Vitamin B, which helps you burn fat.It contains high amounts of lean proteins and low amounts of saturated fat, it helps control weight and reduces the risk of obesity.During pregnancy reduces the risk of birth defects in babies, such as neural tube defects, etc.It is rich in omega-3 fatty acids, goat meat is an effective treatment for autism.'),
(33, 'Chicken', 900, 100, 2, 6, 8, 'chick.jpg', 'Chicken has a very high protein content, which plays a very important role in sustaining our muscles.Eating chicken regularly can help you healthily lose weight.Apart from protein, chicken is also chock full of calcium and phosphorus.It contains tryptophan and vitamin B5.Eating chicken in the form of soup is the best way to recover from most infections'),
(35, 'Rice cooker', 800, 10, 16, 21, 26, 'bread.jpg', 'Simple electronic operation with automatic keep-warm.Seamless thicker outer body with aluminum food steamer.Easy-to-clean.Non-Stick double inner pot. A transparent glass lid keeps ingredients moist. Anti-bacterial warm mood. Integrated with a safety thermostat confirms better protection.'),
(36, 'Parachute Coconut Oil', 99, 10, 14, 5, 5, 'Parachute Coconut Oil.jpg', 'Nothing but 100% pure coconut oil. Made with the finest hand-picked & naturally sun dried coconuts Untouched by hand- goes through 27 quality tests and 5 stage purification process – for 100% purity every time Unique tamper proof seal- the seal of trust. Long lasting freshness & nutty aroma Contains no added preservatives or chemicals.'),
(37, 'Revlon Colorsilk B Color Black ', 99, 10, 14, 23, 12, 'Revlon Colorsilk B Color Black.jpg', 'Revlon Color silk Beautiful Color Black 10 is the ammonia-free hair color. It gives 100% coverage to the grey hairs. It is long-lasting, high-definition color and shine. It delivers rich, natural-looking, multi-tonal color from root to tip.'),
(38, 'Ruchi Premium Mix Chanachur', 99, 10, 8, 17, 5, 'Ruchi Premium Mix Chanachur.jpg', 'Ruchi Premium Mix Chanachur (100g) is available in Buy 2 Get 1 Ruchi BBQ Chanachur Free offer. Ruchi Premium Mix Chanachur an authentic Bengali snack. It contains a mix of peanuts, flattened rice, mixed spices, and others. It has really a unique taste to invoke an amazing excitement and fondness.'),
(39, 'Papaya Ripe Thai Bulk', 69, 50, 3, 24, 8, 'Papaya Ripe Thai Bulk.jpg', 'Papaya also known as Carica Papaya, it has an elongated shape with yellow-orange color that makes it juicy and so favorable. The ripe fruit can be eaten cooked and is used as an ingredient in salads and stews. Ripe papaya has a lot of health benefits as it helps cleanse the body internally of any toxins, eating ripe papaya daily helps with skin conditions like acne blemishes and pigmentation, may help in lowering blood sugar and ease digestion.'),
(40, 'Dates', 56, 50, 3, 3, 8, 'Dates.jpg', 'Premium Maryam Dates - 500 g the fruit of the date palm tree.This is 100% organic and chemical free product. It is fully organic, imported from Iran and Saudi Arabia without any quality loss. It contains rich vitamins and minerals.Taste of Premium Maryam Dates - 500 g feels like enjoying a soft chocolate.'),
(41, 'PRAN HOT TOMATO SAUCE', 56, 50, 6, 25, 8, 'PRAN HOT TOMATO SAUCE.jpg', '\r\nPRAN HOT TOMATO SAUCE 1KG'),
(42, 'Ruchi Chalta Pickle', 23, 50, 6, 26, 5, 'Ruchi Premium Mix Chanachur.jpg', 'The finest mangoes from the best plantations find their place inside the ruchi Chalta pickle jar. Processed with traditional seasoning and spices, Ruchi chalta pickle is the first choice for the mango pickle lovers. The aroma and the taste give Ruchi chalta pickle a different place among all the other branded pickles.'),
(43, 'Aarong Dairy Butter', 89, 10, 7, 27, 5, 'Aarong Dairy Laban.jpg', 'Spread on Bread, Paratha, Roti, Nans, Sandwiches. Provides a significant proportion of the day’s total nutrient. Cooking Medium: Butter Paneer Masala, Butter Corn Masala and thousands of delightful recipes. The morning nourishing breakfast can give you a sense of resilience. Contains milk proteins. Full of nutrition.'),
(44, 'Aarong Sour Curd', 678, 50, 7, 28, 12, 'Aarong Sour Curd.jpg', 'It is prepared through the process of bacterial fermentation of milk. Considered as the world\'s healthiest food because of its amazing health benefits. It is high in calcium and protein. It is beneficial for those who are lactose intolerant and cannot digest milk.\r\n'),
(45, 'Adidas Ice Dive Deo Roll On', 99, 10, 12, 29, 12, 'Adidas Ice Dive Deo Roll On.jpg', 'Anti-Perspirant Deodorant Roll-On for Men 50ml. 48h protection. Fresh and ozonic fragrance. Notes of mint leaves, geranium, and musk. Dermatologically tested and 0% aluminum salts formula that respects skin pH'),
(46, 'Adidas Floral Dream Women Body Spray', 89, 10, 12, 30, 12, 'Adidas Floral Dream Women Body Spray.jpg', 'Surround yourself with the gentle aroma of Adidas Flora Dream and flourish in its bouncy yet down-to-earth notes of rose and tonka bean. Ideal for women who desire refinement and freshness, this scent boasts a spicy bergamot top note that precedes bursts of savory vanilla and white lily, creating depth and an inner complexity. Adidas Floral Dream brings excitement to social or professional events without overpowering the noses of those around you'),
(47, 'Gillette Blue 3 Shaving Razor', 56, 10, 13, 31, 26, 'Gillette Blue 3 Shaving Razor.jpg', '3 Independently mounted spring blades.A pivoting head that adjusts to the contours of your face for a smooth shave.Designed to offer a gentle shave for guys with sensitive skin.Pivoting head adjusts to the contours of your face.Soft ultra grip handle for high control'),
(48, 'Clariss Jasmine Air Freshener', 67, 10, 19, 32, 12, 'Adidas Floral Dream Women Body Spray.jpg', 'Blunt Xtreme Ultimate Jasmine Type Clariss Air Freshener. 100% Ultra Concentrated Oil Based Spray. Ideal for Bathroom, Home, Car, Office & More.'),
(49, 'Aci Aerosol Insect Spray', 67, 10, 20, 33, 12, 'cake-1.jpg', 'ACI Aerosol has been the number one choice of Insect Spray in Bangladesh. The effort to ensure the highest quality has helped ACI to be the most effective. To ensure world-class efficacy an. safety for humans, chemicals are acquired from a world-renowned Japanese company.'),
(50, 'Boroline Cream', 45, 50, 26, 34, 5, 'sub_cat_img_3.jpg', 'Antiseptic Ayurvedic Cream. Heals cracked heels, sunburns, scars & Protects against rashes. Softens rough hands and elbows as well as Prevents skin infection from spreading. Protects the affected skin against germs and facilitates the rapid growth of epidermal cells.'),
(64, 'abcd', 30, 5, 19, 32, 27, 'Aarong Dairy Laban.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `customer_id` int(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `rating` int(20) NOT NULL,
  `published` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `shipping_address`
--

CREATE TABLE `shipping_address` (
  `shipping_id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` int(11) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `billing_address` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `country` varchar(200) NOT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shipping_address`
--

INSERT INTO `shipping_address` (`shipping_id`, `first_name`, `last_name`, `email`, `phone`, `Address`, `billing_address`, `city`, `country`, `customer_id`) VALUES
(3, 'masud', 'rana', 'masudrana100855@gmail.com', 1754345543, 'ert', 'rrrrrrrrrrrrrrrr', 'wtew', 'Bangladesh', 4),
(4, 'masud', 'rana', 'masudrana100855@gmail.com', 1754345543, 'ert', 'rrrrrrrrrrrrrrrr', 'wtew', 'Bangladesh', 4);

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_cat_id` int(30) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `status` varchar(5) NOT NULL,
  `cat_id` int(30) NOT NULL,
  `sub_cat_img` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_cat_id`, `s_name`, `status`, `cat_id`, `sub_cat_img`) VALUES
(1, 'cooking essentials', '1', 1, 'sub_cat_img_1.jpg'),
(2, 'meat & fish', '1', 1, 'mutton.jpg'),
(3, 'fruits & vegetables', '1', 1, 'sub_cat_img_3.jpg'),
(4, 'breads, biscuits & cakes', '1', 1, 'sub_cat_img_4.jpg'),
(5, 'spreads', '1', 1, 'sub_cat_img_5.jpg'),
(6, 'sauces & pickles', '1', 1, 'sauces & pickles.jpg'),
(7, 'milk & dairy products', '1', 1, 'milk & dairy products.jpg'),
(8, 'snacks & instant foods', '1', 1, 'snacks & instant foods.jpg'),
(9, 'drinks', '1', 1, 'drinks.jpg'),
(10, 'skin care', '1', 2, 'skin care.jpg'),
(11, 'hair care', '1', 2, 'hair care.jpg'),
(12, 'fragrance', '1', 2, 'fragrance.jpg'),
(13, 'bath & body care', '1', 3, 'bath & body care.jpg'),
(14, 'hair care', '1', 3, 'hair care.jpg'),
(15, 'oral care', '1', 3, 'oral care.jpg'),
(16, 'cookware', '1', 4, 'cookware.jpg'),
(17, 'electronic items', '1', 4, 'electronic items.jpg'),
(18, 'spoon, forks & others', '1', 4, 'spoon, forks & others.jpg'),
(19, 'air freshner', '1', 4, 'air freshner.jpg'),
(20, 'mosquito aerosol', '1', 4, 'mosquito aerosol.jpg'),
(21, 'umbrella', '1', 4, 'umbrella.jpg'),
(22, 'paddle bin', '1', 4, 'paddle bin.jpg'),
(23, 'blanket & comforter', '1', 4, 'blanket & comforter.jpg'),
(24, 'towels', '1', 4, 'towels.jpg'),
(25, 'toiletries', '1', 4, 'toiletries.jpg'),
(26, 'first aid', '1', 5, 'first aid.jpg'),
(27, 'family planning', '1', 5, 'family planning.jpg'),
(28, 'antiseptic', '1', 5, 'antiseptic.jpg'),
(29, 'sanitizer', '1', 5, 'sanitizer.jpg'),
(30, 'baby diapers', '1', 6, 'baby diapers.jpg'),
(31, 'baby wipes', '1', 6, 'baby wipes.jpg'),
(32, 'baby accessories', '1', 6, 'baby accessories.jpg'),
(33, 'baby food', '1', 6, 'baby food.jpg'),
(34, 'special offers', '1', 7, ''),
(35, 'education', '1', 7, 'baby wipes.jpg'),
(36, 'fashion & life styles', '1', 7, '129850958_2733690443561771_7547181352691706537_o.jpg'),
(37, 'pet care', '1', 7, '82069079_2788030574593822_5973672241647321088_o.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `type_id` int(11) NOT NULL,
  `t_name` varchar(100) DEFAULT NULL,
  `sub_cat_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`type_id`, `t_name`, `sub_cat_id`) VALUES
(1, 'rice', 1),
(3, 'spices and mixes', 1),
(4, 'daal', 1),
(5, 'oil', 1),
(6, 'meat', 2),
(7, 'fish', 2),
(8, 'Dry fruits', 3),
(10, 'Soft drinks', 9),
(11, 'green leaf', 3),
(12, 'Yellow vegetables', 3),
(13, 'Sea fish', 2),
(14, 'baby food', 33),
(15, 'baby accessories', 32),
(16, 'baby diapers', 30),
(17, 'breads, biscuits & cakes', 4),
(18, 'bath & body care', 13),
(19, 'Lotion', 10),
(20, 'Shower gell', 10),
(21, 'Electric cooker', 16),
(23, 'hair color', 14),
(24, 'Fruits', 3),
(25, 'sauces ', 6),
(26, 'pickles', 6),
(27, 'Butter', 7),
(28, 'Curd', 7),
(29, ' Deo', 12),
(30, 'Women Body Spray', 12),
(31, 'Shaving Razor', 13),
(32, 'room freshener', 19),
(33, 'Insect Spray', 20),
(34, 'antiseptic', 26),
(35, 'flour', 1),
(36, 'saree', 36);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `unit_id` int(30) NOT NULL,
  `u_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`unit_id`, `u_name`) VALUES
(1, 'liter'),
(5, 'gm'),
(8, 'kg'),
(12, 'ml'),
(26, 'EA'),
(27, 'piece');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wish_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wish_id`, `customer_id`, `product_id`) VALUES
(7, 4, 27),
(10, 4, 1),
(11, 4, 2),
(12, 4, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `sub_category` (`sub_cat_id`),
  ADD KEY `type` (`type_id`),
  ADD KEY `unit` (`unit_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `product` (`product_id`),
  ADD KEY `customer` (`customer_id`);

--
-- Indexes for table `shipping_address`
--
ALTER TABLE `shipping_address`
  ADD PRIMARY KEY (`shipping_id`),
  ADD KEY `billig_fk` (`customer_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_cat_id`),
  ADD KEY `category` (`cat_id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`type_id`),
  ADD KEY `type_id` (`sub_cat_id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`wish_id`),
  ADD KEY `c_fk` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `review_id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shipping_address`
--
ALTER TABLE `shipping_address`
  MODIFY `shipping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_cat_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `unit_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `wish_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `customer` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `shipping_address`
--
ALTER TABLE `shipping_address`
  ADD CONSTRAINT `billig_fk` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD CONSTRAINT `category` FOREIGN KEY (`cat_id`) REFERENCES `category` (`cat_id`);

--
-- Constraints for table `type`
--
ALTER TABLE `type`
  ADD CONSTRAINT `type_ibfk_1` FOREIGN KEY (`sub_cat_id`) REFERENCES `sub_category` (`sub_cat_id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `c_fk` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
